<?php
include 'db.php';

echo "<h2>Fetch Methods</h2>";

// Fetch as Associative Array
$stmt = $pdo->query("SELECT id, name, email FROM users");
echo "<h3>FETCH_ASSOC</h3>";
while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    echo "ID: {$row['id']}, Name: {$row['name']}, Email: {$row['email']} <br>";
}

// Fetch as Numeric Array
$stmt = $pdo->query("SELECT id, name, email FROM users");
echo "<h3>FETCH_NUM</h3>";
while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
    echo "ID: $row[0], Name: $row[1], Email: $row[2] <br>";
}

// Fetch as Object
$stmt = $pdo->query("SELECT id, name, email FROM users");
echo "<h3>FETCH_OBJ</h3>";
while ($row = $stmt->fetch(PDO::FETCH_OBJ)) {
    echo "ID: {$row->id}, Name: {$row->name}, Email: {$row->email} <br>";
}

// Fetch All Rows at Once
$stmt = $pdo->query("SELECT id, name, email FROM users");
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
echo "<h3>FETCH_ALL</h3>";
foreach ($rows as $row) {
    echo "ID: {$row['id']}, Name: {$row['name']}, Email: {$row['email']} <br>";
}
?>
